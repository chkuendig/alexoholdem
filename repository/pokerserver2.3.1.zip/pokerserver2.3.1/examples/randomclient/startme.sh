java -cp pokerserver.jar ca.ualberta.cs.poker.free.client.RandomPokerClient $1 $2
